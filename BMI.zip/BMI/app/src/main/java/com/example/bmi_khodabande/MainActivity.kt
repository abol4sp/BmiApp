package com.example.bmi_khodabande

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import com.example.bmi_khodabande.databinding.ActivityMainBinding
import java.text.DecimalFormat

@Suppress("UNREACHABLE_CODE")
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        emptys()
        binding.button2.setOnClickListener {
            val result = vazn()
            binding.txtresult.text = " $result".toString()
        }
        binding.thrashImage.setOnClickListener {
            binding.editTextGhad.text?.clear()
            binding.editTextVazn.text?.clear()
            binding.txtresult.text = " "

        }

    }

    private fun emptys() {
        try {
            if (binding.editTextGhad.text.toString().isEmpty()) {
                Toast.makeText(this, "لطفا مقادیر را پر کنید", Toast.LENGTH_SHORT).show()
            }

            if (binding.editTextVazn.text.toString().isEmpty()) {
                Toast.makeText(this, "لطفا مقادیر را پر کنید", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun ghad(): Float {
        val number1 = binding.editTextGhad.text.toString().toFloat()
        val ashar = number1 / 100
        return ashar * ashar
    }

    private fun vazn(): String {
        val number2 = binding.editTextVazn.text.toString().toFloat()
        val result = number2 / ghad()
        return "%.1f".format(result)
    }
}


//private fun vazn(): String {
//val number2 = binding.editTextNumber4.text.toString().toInt()
//val result = number2 / ghad()
//return "$result"